sap.ui.define(["sap/ui/core/mvc/Controller", "sap/m/MessageBox"], function (Controller) {
	"use strict";
	return Controller.extend("user_ui.user_ui.controller.UserForm", {
		/**
		 *@memberOf user_ui.user_ui.controller.UserForm
		 */
		OnProcess: function (oEvent) {
			var oLocal = this.getView().getModel("local");
			var oBundle = this.getView().getModel("i18n");

			var sFirstLabel = oBundle.getProperty("firstName");
			var sLastLabel = oBundle.getProperty("lastName");
			var sFirstName = oLocal.getProperty("/FirstName");
			var sLastName = oLocal.getProperty("/LastName");

			var sMessage = sFirstLabel + ": " + sFirstName + "\n" +
						sLastLabel + ": " + sLastName;

			sap.m.MessageBox.show(sMessage);
		}
	});
});