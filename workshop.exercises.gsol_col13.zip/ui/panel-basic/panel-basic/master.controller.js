jQuery.sap.require("sap.m.MessageBox");
sap.ui.controller("panel-basic.master", {
	
	_oInputFirstName: null,
	_oInputLastName: null,
	
	onInit: function() {
		
		this._oInputFirstName = this.getView().byId("idInputFirstName");
		this._oInputLastName = this.getView().byId("idInputLastName");
				
	},

	onButtonPressed: function(oEvent){
		
		var sFirstName = this._oInputFirstName.getValue();
		var sLastName = this._oInputLastName.getValue();
		
		var sMessage =  "First Name: " + sFirstName + "\n" + 
						"Last Name: " + sLastName;
		
		sap.m.MessageBox.show(sMessage,{
			title: "Welcome!"
		});
	}
	
});