jQuery.sap.require("sap.m.MessageBox");
sap.ui.controller("view.UserOverview", {
	
	_oTableUserOverview: undefined,
	_oInputPersNo: undefined,
	_oInputFirstName: undefined,
	_oInputLastName: undefined,
	_oInputEmail: undefined,
	
	_oButtonDownload: undefined,
	
	onInit: function(){
		
		this._oTableUserOverview = this.getView().byId("idTableUserOverview");
		this._oInputFirstName = this.getView().byId("idInputFirstName");
		this._oInputLastName = this.getView().byId("idInputLastName");
		this._oInputEmail = this.getView().byId("idInputEmail");
		
		this._oButtonDownload = this.getView().byId("idButtonDownload");
		
		// Model for user input
		var oUserModel = new sap.ui.model.json.JSONModel({
			FIRSTNAME: "",
			LASTNAME: "",
			E_MAIL: ""
		});
		this.getView().setModel(oUserModel);
		
		// Model for server data
		var oUserCollectionModel = new sap.ui.model.odata.ODataModel(
        		"../../services/user.xsodata", true
        );
		oUserCollectionModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
		this.getView().setModel(oUserCollectionModel, "Users");
		
		// Model for Server Info from XSJS Service
		var oServerInfoModel = new sap.ui.model.json.JSONModel("../../services/HelloWorld.xsjs?json=true");
		this.getView().setModel(oServerInfoModel, "ServerInfo");
		
		// Model for Download Options
		var oDownloadOptionsModel = new sap.ui.model.json.JSONModel({
			limit: ""
		});
		this.getView().setModel(oDownloadOptionsModel, "DownloadOptions");
		
	},
	
	onUserCreate: function(oEvent){
		
		var oNewUser = this.getView().getModel().oData;
		
		jQuery.ajax({
			url: "../../services/CreateUser.xsjs",
			method: 'GET',
			data: oNewUser,
			dataType: 'JSON',
			context: this,
			success: function(){
				sap.m.MessageBox.alert("The new user has been created.");
				this.getView().getModel("Users").refresh();
			},
			error: function(){
				sap.m.MessageBox.alert("The new user wasn't created!");
			}
		});
	},
	
	onFormClear: function(oEvent){
		
		this._oInputFirstName.setValue();
		this._oInputLastName.setValue();
		this._oInputEmail.setValue();
		
	},
	
	onUserDelete: function(oEvent){
		var oUserCollectionModel = this.getView().getModel("Users");
		var oSelectedItem = this._oTableUserOverview.getSelectedItem();
		
		if(oSelectedItem !== null){
			oUserCollectionModel.remove(oSelectedItem.getBindingContextPath());			
		
		}else{
			
			sap.m.MessageBox.alert("Select an item before you continue!");
		}
	},
	
	onDownloadLimitChange: function(oEvent){
		var vLimit = oEvent.getSource().getValue();
		
		if($.isNumeric(vLimit)){
			
			this._oButtonDownload.setEnabled(true);
			
		}else{
			
			this._oButtonDownload.setEnabled(false);
		}
	},
	
	onDownload: function(){
		
		var vLimit = this.getView().getModel("DownloadOptions").getProperty("/limit");
		
		window.open("../../services/DownloadUserList.xsjs?limit=" + vLimit);
		
	}
});