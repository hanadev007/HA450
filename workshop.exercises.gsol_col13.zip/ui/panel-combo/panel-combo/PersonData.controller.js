jQuery.sap.require("sap.m.MessageBox");
sap.ui.controller("panel-combo.PersonData", {
	
	onInit: function() {
		
		var oPersonModel = new sap.ui.model.json.JSONModel({
			firstName: "",
			lastName: "",
			countryCode: ""
		});
		this.getView().setModel(oPersonModel);
		
		var oCountryModel = new sap.ui.model.json.JSONModel({
			CountryCollection: [
			    {Name: "Germany", CountryCode: "DE"},
			    {Name: "Italy", CountryCode: "IT"},
			    {Name: "France", CountryCode: "FR"}
			]
		});
		this.getView().setModel(oCountryModel, "Countries");
	},

	onButtonPressed: function(oEvent){
		
		var oPersonModel = this.getView().getModel();
		
		var sFirstName = oPersonModel.getProperty("/firstName");
		var sLastName = oPersonModel.getProperty("/lastName");
		var sCountryCode = oPersonModel.getProperty("/countryCode");
		
		var sMessage =  "First Name: " + sFirstName + "\n" + 
						"Last Name: " + sLastName + "\n" + 
						"Country: " + sCountryCode;
		
		sap.m.MessageBox.show(sMessage,{
			title: "Welcome!"
		});
	}
});