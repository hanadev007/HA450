jQuery.sap.require("sap.m.MessageBox");
sap.ui.controller("panel-binding.PersonData", {
	
	onInit: function() {
		
		var oPersonModel = new sap.ui.model.json.JSONModel({
			firstName: "",
			lastName: ""
		});
		
		this.getView().setModel(oPersonModel);
	},

	onButtonPressed: function(oEvent){
		
		var oPersonModel = this.getView().getModel();
		
		var sFirstName = oPersonModel.getProperty("/firstName");
		var sLastName = oPersonModel.getProperty("/lastName");
		
		var sMessage =  "First Name: " + sFirstName + "\n" + 
						"Last Name: " + sLastName;
		
		sap.m.MessageBox.show(sMessage,{
			title: "Welcome!"
		});
	}
});