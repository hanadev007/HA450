sap.ui.jsview("panel-mvc-js.PersonData", {

	getControllerName : function() {
		return "panel-mvc-js.PersonData";
	},

	createContent : function(oController) {

		// Create Panel
		var oPanel = new sap.ui.commons.Panel("panel", { text : "Enter Data"});
        
		// Create Controls
		var oLabel1 = new sap.ui.commons.Label({text : "First Name:"});
        var oTextField1 = new sap.ui.commons.TextField("Field1");
        var oLabel2 = new sap.ui.commons.Label({text : "Last Name:"});
        var oTextField2 = new sap.ui.commons.TextField("Field2");
        
        var oButton = new sap.ui.commons.Button({
        	text : "Submit", 
        	press: oController.onSubmit
        });
              
        // Put controls in a Layout
        var oLayout = new sap.ui.commons.layout.VerticalLayout("Layout1", {
            content : [ oLabel1, oTextField1, oLabel2, 
                        oTextField2, oButton ]});
       
        // Put Layout in the Panel
        oPanel.addContent(oLayout);
        
		return oPanel;
	}
});
