sap.ui.controller("panel-mvc-js.PersonData", {

	onSubmit: function() {
		var msg = "First Name: " + sap.ui.getCore().byId("Field1").getValue() 
		+ "\n" + "Last Name: " + sap.ui.getCore().byId("Field2").getValue();
	    alert(msg);	
	}	

});
