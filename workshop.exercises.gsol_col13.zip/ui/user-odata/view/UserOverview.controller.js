sap.ui.controller("view.UserOverview", {

	onInit: function() {
		
		var oUserOverviewModel = new sap.ui.model.odata.ODataModel(
        		"/workshop/exercises/gsol_col13/services/user.xsodata/", true
        );
		this.getView().setModel(oUserOverviewModel, "Users");
	}
});