/*eslint no-console: 0*/
"use strict";

// Create the Express application framework
var express = require("express");
var app = express();

// Set the port the application listens to
var port = process.env.PORT || 3000;
app.listen(port, function() {
	console.log("listening on port " + port);
});

// Get XS services
var xsenv = require("sap-xsenv");
var services = xsenv.getServices({
	hana: {tag: "hana"}
});

// Get HANA middleware and assign it to the application 
var hdbext = require("sap-hdbext");
app.use("/", hdbext.middleware(services.hana));

// Set the function to be executed when you access the application URL
app.get(
	"/",
	function(req, res, next) {
		req.db.exec(
			"SELECT COUNT(EMPLOYEEID) AS COUNT FROM \"MD.Employees\"",
			function(err, rows) {
				if (err) {
					return next(err);
				}
				res.send("Current employees: " + rows[0].COUNT);
			}
		);
	}
);
