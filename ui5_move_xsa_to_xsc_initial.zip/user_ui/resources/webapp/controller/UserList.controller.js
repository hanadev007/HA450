sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/m/MessageBox"
], function(Controller) {
	"use strict";
	return Controller.extend("user_ui.controller.UserList", {
		/**
		 *@memberOf user_ui.controller.UserList
		 */
		onCreate: function() {
			var oLocal = this.getView().getModel("local");
			var oService = this.getView().getModel();
			var oBundle = this.getView().getModel("i18n");

			var oNewUser = oLocal.getProperty("/User");

			oService.create("/Users", oNewUser, {
				success: function() {
					sap.m.MessageBox.alert(oBundle.getProperty("createSuccessMessage"));
				},
				error: function(oError) {
					var response = JSON.parse(oError.responseText);
					var errorMessage = response.error.message.value;
					sap.m.MessageBox.alert(oBundle.getProperty("createErrorMessage") + errorMessage);
				}
			});
		},
		/**
		 *@memberOf user_ui.controller.UserList
		 */
		onSelectionChange: function(oEvent) {
			var oLocal = this.getView().getModel("local");
			var selectedItem = oEvent.getSource().getSelectedItem();
			var path = selectedItem.getBindingContext().getPath();
			oLocal.setProperty("/SelectedUserPath", path);
		},
		/**
		 *@memberOf user_ui.controller.UserList
		 */
		onDelete: function() {
			var oLocal = this.getView().getModel("local");
			var oService = this.getView().getModel();
			var oBundle = this.getView().getModel("i18n");

			var path = oLocal.getProperty("/SelectedUserPath");
			if (path === "") {
				sap.m.MessageBox.alert(oBundle.getProperty("deleteNoSelectionMessage"));
			} else {
				oService.remove(path, {
					success: function() {
						sap.m.MessageBox.alert(oBundle.getProperty("deleteSuccessMessage"));
						oLocal.setProperty("/SelectedUserPath", "");
					},
					error: function(oError) {
						var response = JSON.parse(oError.responseText);
						var errorMessage = response.error.message.value;
						sap.m.MessageBox.alert(oBundle.getProperty("deleteErrorMessage") + errorMessage);
					}
				});
			}
		}
	});
});